package com.capstone.injureal

data class HistoryItem(
    val imageUrl: String,
    val woundName: String,
    val description: String
)
