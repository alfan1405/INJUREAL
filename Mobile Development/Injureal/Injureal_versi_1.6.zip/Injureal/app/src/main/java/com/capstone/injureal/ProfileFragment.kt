package com.capstone.injureal

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.capstone.injureal.R
import com.google.firebase.firestore.FirebaseFirestore

class ProfileFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        val usernameTextView = view.findViewById<TextView>(R.id.username)
        val emailTextView = view.findViewById<TextView>(R.id.email)
        val editProfileButton = view.findViewById<Button>(R.id.btnEditProfile)
        val signOutButton = view.findViewById<Button>(R.id.btnSignOut)

        val sharedPreferences = requireActivity().getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val username = sharedPreferences.getString("username", "Unknown User")
        val email = sharedPreferences.getString("email", "Unknown Email")

        usernameTextView.text = username
        emailTextView.text = email

        editProfileButton.setOnClickListener {
            showEditProfileDialog(sharedPreferences, usernameTextView, emailTextView)
        }

        signOutButton.setOnClickListener {
            sharedPreferences.edit().clear().apply()
            Toast.makeText(requireContext(), "Signed out successfully!", Toast.LENGTH_SHORT).show()
            requireActivity().finish()
        }

        return view
    }

    private fun showEditProfileDialog(
        sharedPreferences: android.content.SharedPreferences,
        usernameTextView: TextView,
        emailTextView: TextView
    ) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.activity_edit_profile, null)
        val usernameEditText = dialogView.findViewById<EditText>(R.id.etUsername)
        val emailEditText = dialogView.findViewById<EditText>(R.id.etEmail)

        usernameEditText.setText(sharedPreferences.getString("username", ""))
        emailEditText.setText(sharedPreferences.getString("email", ""))

        AlertDialog.Builder(requireContext()).apply {
            setTitle("Edit Profile")
            setView(dialogView)
            setPositiveButton("Save") { _, _ ->
                val newUsername = usernameEditText.text.toString().trim()
                val newEmail = emailEditText.text.toString().trim()

                if (newUsername.isNotEmpty() && newEmail.isNotEmpty()) {
                    val db = FirebaseFirestore.getInstance()
                    val userId = sharedPreferences.getString("userId", null)

                    if (userId != null) {
                        val userRef = db.collection("users").document(userId)
                        val updatedData = mapOf(
                            "et_name" to newUsername,
                            "et_email" to newEmail
                        )
                        userRef.update(updatedData)
                            .addOnSuccessListener {
                                sharedPreferences.edit().apply {
                                    putString("username", newUsername)
                                    putString("email", newEmail)
                                    apply()
                                }
                                usernameTextView.text = newUsername
                                emailTextView.text = newEmail
                                Toast.makeText(requireContext(), "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(requireContext(), "Failed to update profile: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                    } else {
                        Toast.makeText(requireContext(), "User ID not found in SharedPreferences!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "Fields cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            setNegativeButton("Cancel", null)
        }.create().show()
    }
}