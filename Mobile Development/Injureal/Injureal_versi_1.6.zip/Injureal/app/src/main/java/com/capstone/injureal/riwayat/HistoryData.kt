package com.capstone.injureal.riwayat

import com.capstone.injureal.HistoryItem

object HistoryData {
    val historyList = mutableListOf<HistoryItem>()
}
