package com.capstone.injureal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.capstone.injureal.riwayat.PredictionHistory

class HistoryDetailFragment : Fragment() {

    private lateinit var historyImageView: ImageView
    private lateinit var woundNameTextView: TextView
    private lateinit var descriptionTextView: TextView

    companion object {
        const val ARG_HISTORY_ITEM = "history_item"

        fun newInstance(historyItem: PredictionHistory): HistoryDetailFragment {
            val fragment = HistoryDetailFragment()
            val args = Bundle()
            args.putParcelable(ARG_HISTORY_ITEM, historyItem)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_history_detail, container, false)

        historyImageView = view.findViewById(R.id.detailImageView)
        woundNameTextView = view.findViewById(R.id.tvDetailWoundName)
        descriptionTextView = view.findViewById(R.id.tvDetailDescription)

        // Load data from arguments
        val historyItem: PredictionHistory? = arguments?.getParcelable(ARG_HISTORY_ITEM)
        if (historyItem != null) {
            populateData(historyItem)
        }

        return view
    }

    private fun populateData(historyItem: PredictionHistory) {
        // Set data to views
        Glide.with(this).load(historyItem.imageUrl).into(historyImageView)
        woundNameTextView.text = historyItem.woundName
        descriptionTextView.text = historyItem.description
    }
}
