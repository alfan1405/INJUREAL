package com.capstone.injureal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.capstone.injureal.riwayat.PredictionHistory

class HistoryAdapter(
    private val predictionList: MutableList<PredictionHistory>
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    // Listener untuk tombol hapus
    private var deleteClickListener: OnDeleteClickListener? = null

    interface OnDeleteClickListener {
        fun onDeleteClick(position: Int)
    }

    fun setOnDeleteClickListener(listener: OnDeleteClickListener) {
        deleteClickListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // Inflate layout item_history.xml
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val prediction = predictionList[position]

        // Load gambar menggunakan Glide
        Glide.with(holder.itemView.context)
            .load(prediction.imageUrl) // URL gambar
            .placeholder(R.drawable.ic_place_holder) // Gambar placeholder jika URL tidak valid
            .into(holder.historyImage)

        // Set data ke TextView
        holder.woundName.text = prediction.woundName
        holder.description.text = prediction.description

        // Handle klik tombol hapus
        holder.deleteButton.setOnClickListener {
            deleteClickListener?.onDeleteClick(position)
        }

        holder.itemView.setOnClickListener {
            val fragment = HistoryDetailFragment.newInstance(prediction)
            (holder.itemView.context as? AppCompatActivity)?.supportFragmentManager
                ?.beginTransaction()
                ?.replace(R.id.fragmentContainer, fragment)
                ?.addToBackStack(null)
                ?.commit()
        }

    }

    override fun getItemCount(): Int {
        return predictionList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Referensi komponen di item_history.xml
        val historyImage: ImageView = itemView.findViewById(R.id.history_image)
        val woundName: TextView = itemView.findViewById(R.id.wound_name)
        val description: TextView = itemView.findViewById(R.id.description)
        val deleteButton: Button = itemView.findViewById(R.id.delete_button)
    }
}